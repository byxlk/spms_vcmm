
void AddIdentityFaultCnt( void );					
void InitFaultCnt( void );
int GetIdentityValidState( void );						
