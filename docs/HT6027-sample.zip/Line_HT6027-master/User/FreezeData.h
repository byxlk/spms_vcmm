

void ComplementDayFreeze( unsigned char* STime, unsigned char* ETime );							
void AppointFreeze( unsigned int Freeze_No );
void AppointHourFreeze( void );
