#include "TypeMeter.h"
#include "TypeE2p.h"
#include "TypeRAM.h"
//#include "msp430x54x.h"
//#include "In430.h"
#include "ht6xxx_lib.h"
#include "DLT698.h"					
#include "Port.h"
#include "TypeFRAM.h"
#include "RsComm.h"
#include "Data.h"
#include "interrupt.h"
#include "Mem.h"
#include "Measure.h"
#include "General.h" 
#include "Time.h"
#include "Power.h"
#include "Display.h"
#include "FreezeData.h"
//#include "Load.h"
#include "cpucard.h"
#include "RemoteComm.h"

void ComplementDayFreeze( unsigned char* STime, unsigned char* ETime )							//�¹���
{
	
}

void AppointFreeze( unsigned int Freeze_No )
{

}

void AppointHourFreeze( void )
{

}