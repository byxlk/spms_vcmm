short GetRegister_ActivationClassData( unsigned char* Dest, unsigned char* Source ); 
unsigned char SetRegister_ActivationClassData( unsigned char *Source , unsigned short DataLen );
short Judge_Register_Activation_objects( unsigned char* Data, unsigned char Tab_No, unsigned char Attribute_No );
void initialRegister_ActivationPara( void );
unsigned char ActionRegister_ActivationClassData( unsigned char *Source, unsigned short DataLen );

