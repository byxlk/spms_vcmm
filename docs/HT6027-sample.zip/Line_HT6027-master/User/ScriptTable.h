
short GetScript_tableClassData( unsigned char* Dest, unsigned char* Source );
unsigned char ActionScript_tableClassData( unsigned char *Source, unsigned short DataLen );

void Exec_ScriptTable( unsigned char* script_logical_name, unsigned short script_selector );
unsigned char SetScript_TableClassData( unsigned char *Source , unsigned short DataLen );
short Judge_Script_Table_objects( unsigned char* Data, unsigned char Tab_No );
unsigned char GetScript_tableAccessPurview( unsigned char* Logical_Name );
short Judge_Test_Normal_Table_objects( unsigned char* Data, unsigned char Tab_No );

void initialTariffication_Script_TablePara( void );
void Clr_local_control_para_monitor( void );
///void OperateRelay( void );
///void Clr_local_control_para_monitor( void );
void Class9_ScriptTable( unsigned char* script_logical_name, unsigned short script_selector );

